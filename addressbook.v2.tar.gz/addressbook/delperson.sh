#!/bin/bash 
# delperson
# del a person from addressbook
# args:$1-> name of person to delete

#get the helper function
. /home/shiwei2/linux/shell/addressbook/libComm.sh
PATH=/bin:/usr/bin

if [ $# -lt 1 ];then
    printUSAGE "`basename $0 ` name "
    exit 1
fi

MYADDRESSBOOK="/home/shiwei2/linux/shell/addressbook/addressbook"
if [ ! -f "$MYADDRESSBOOK" ];then
    printERROR "$MYADDRESSBOOK does not exists, or is not a file"
    exit 1
fi

#temp file location
TMPF1=/home/shiwei2/linux/shell/addressbook/apupdate.$$
TMPF2=/home/shiwei2/linux/shell/addressbook/abdelets.$$
touch $TMPF1 $TMPF2;

doCleanUp(){
    rm "$TMPF1" "$TMPF1.new" "$TMPF2" 2>/dev/null
}
Failed() {
    if [ "$1" -ne 0 ];then
        shift
        printERROR $@
        doCleanUp
        exit 1
    fi
}


cp "$MYADDRESSBOOK" "$TMPF1";
# 2>/dev/null
Failed $? "could not make a backup of the address book"

grep "$1" "$TMPF1" > "$TMPF2";
# 2>/dev/null
Failed $? " no matches found"

# prompt the user for each entry that was found
#exec 5<"$TMPF2"
for  LINE in `cat $TMPF2`
# while read LINE <&5
do
    #display each line formatted
    
    echo "$LINE" | awk -F: '{
        printf "%-10s %s\n%-10s %s\n%-10s %s\n%-10s %s",
         "Name:",$1,"Email:",$2,"Address:",$3,"Phone:",$4;

    }'
    #prompt to delete
    promptYESNO "delete this entry" "n"
    echo 'yesno=' $YESNO
    if [ "$YESNO" = "y" ];then
        grep -v "$LINE" "$TMPF1" > "$TMPF1.new" 2>/dev/null
        Failed $? "unable to update the address book"
        # replace the old file
        mv "$TMPF1.new" "$TMPF1" 2>/dev/null
        Failed $? "unable to update the address book"
    fi
done

#exec 5<&-

#save the original version
mv "$MYADDRESSBOOK" "$MYADDRESSBOOK".bak 2>/dev/null
Failed $? "unable to update the address book"

#replace the original with the edited version
mv "$TMPF1" "$MYADDRESSBOOK" 2>/dev/null
Failed $? "unable to update the address book"

#clean up
doCleanUp
exit $?
