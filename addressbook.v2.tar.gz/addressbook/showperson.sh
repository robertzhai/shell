#!/bin/bash
#showperson
#show matching records in addressbook
#args:$1->string to look for in addressbook
PATH=/bin:/usr/bin

if [ $# -lt 1 ];then
    echo "USAGE:./showperson name"
    exit
fi

MYADDRESSBOOK="/home/shiwei2/linux/shell/addressbook/addressbook"
if [ ! -f "$MYADDRESSBOOK" ] ;then
    echo "ERROR $MYADDRESSBOOK does not exist, or is not a file." >&2
    exit 1
fi

grep "$1" "$MYADDRESSBOOK" |
    awk -F: '{
        printf "%-10s %s\n%-10s %s\n%-10s %s\n%-10s %s\n\n",
            "Name:",$1,"Email:",$2,"Address:",$3,"Phone:",$4;
    }'
grep "$1" "$MYADDRESSBOOK" >/dev/null 2>&1 
if [ $? -ne 0 ];then
    echo "no matched person"
fi
