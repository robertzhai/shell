the address book will store the following information
.Name
.Email address
.Postal address
.Phone number
function:
    show people
    delete a person
    add a person
