#!/bin/bash
if [ $# -lt 1 ];then
    echo "no arg";
else 
    echo "$@";
    echo $0
    echo "`basename $0`"
fi
