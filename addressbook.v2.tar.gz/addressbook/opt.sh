#!/bin/bash
# addperson
# args -n name
#      -e email
#      -a postal address
#      -p phone number
#initialize the variables
    #this is noninteractive mode
while getopts n:e:a:p:h OPT
do
        case "$OPT" in
            n) NAME="$OPTARG";;
            e) EMAIL="$OPTARG";;
            a) ADDR="$OPTARG";;
            p) PHONE="$OPTARG";;
            h)
              echo "USAGE:$USAGE" 1>&2;
              exit 1;;
        esac
done

echo $NAME;
