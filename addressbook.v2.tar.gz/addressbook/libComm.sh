#!/bin/bash
# print warning
# args:$@->message to print
printWARNING(){
    echo "WARNING:" $@ >&2
}
printERROR() {
   echo "error :" $@ >&2
}

# print usage
# args:$@->message to print
printUSAGE(){
    echo "USAGE:" $@
    exit
}

# prompt yes or no
# args:$1 -> the prompt
#      $2 -> the default answer(optional)
# vars:YESNO -> set to the users response y for yes, n for no
promptYESNO(){
     echo " execute lib function";
     echo $@
    if [ $# -lt 1 ];then
        printERROR "Insufficient Arguments."
        return 1
    fi
    DEF_ARG=""
    YESNO=""
    case "$2" in
        [yY][eE][sS]|y)
            DEF_ARG=y;;
        [nN]|[nN][oO])
            DEF_ARG=n;;
    esac

    while :
    do
        printf "$1 (yes/no)?"
        if [ -n "$DEF_ARG" ];then
            printf "[$DEF_ARG]"
        fi
        read YESNO
        echo "yesno: $YESNO"
        if [ -z "$YESNO" ];then
            YESNO="$DEF_ARG"
        fi
        
        case "$YESNO" in
            [yY][eE][sS]|[yY])
                YESNO=y;
                 break;
                ;;
            [nN]|[nN][oO])
                YESNO=n
                break;
                ;;
        esac
    done

    export YESNO    
    unset DEF_ARG
    return 0
}

# prompt response
# ask a question
# args:$1->the prompt
#      $2->the default answer
# vars: RESPONSE->set to the users response
promptRESPONSE(){
    if [ $# -l 1 ];then
        printERROR "Insufficient Arguments."
        return 1
    fi
    RESPONSE=""
    DEF_ARG="$2"
    
    while :
    do
        printf "$1 ?"
        if [ -n "$DEF_ARG" ];then
            printf "[$DEF_ARG]"
        fi
        read RESPONSE
        if [ -n "$RESPONSE" ];then
            break
        elif [ -z "$RESPONSE" -a -n "$DEF_ARG" ];then
            RESPONSE="$DEF_ARG"
            break
        fi
    done
    export RESPONSE
    unset DEF_ARG
    return 0

}

# getSpaceFree
# output the space avail for a directory
# args:$1->the directory to check
getSpaceFree(){
    if [ $# -lt 1 ];then
        printERROR "Insufficient Arguments"
        return 1
    fi
    df -k "$1" | awk 'NR != 1{print $4;}'
}
#getSpaceUsed
#output the space used for a directory
#args:$1->the directory to check
getSpaceUsed(){
    if [ $# -lt 1 ];then
        printERROR "Insufficient Arguments"
        return 1
    fi
    
    if [ ! -d "$1" ];then
        printERROR "$1 is not a directory"
        return 1
    fi
    du -sk "$1" | awk '{print $1;}'
}

#getPid
#outputs a list of process id matching $1
#args:$1->the command name to look for
getPID(){
    if [ $# -lt 1 ];then
        printERROR "Insufficient Arguments"
        return 1
    fi
    PSOPTS="-ef"
    /bin/ps $PSOPTS | grep "$1" | grep -v grep | awk '{print $2}'
}

# getUID
# output a numeric user id
# args:$1->a user name (optional)
getUID(){
    id $1 | sed -e 's/(.*$//' -e 's/^uid=//'
}




































