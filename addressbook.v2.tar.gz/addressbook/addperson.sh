#!/bin/bash
# addperson
# args -n name
#      -e email
#      -a postal address
#      -p phone number

#initialize the variables
PATH=/bin:/usr/bin
MYADDRESSBOOK="/home/shiwei2/linux/shell/addressbook/addressbook"
NAME=""
EMAIL=""
ADDR=""
PHONE=""

#remove the : from user input
remove_colon(){
    echo "$@" | tr ':' ' ';
}

if [ $# -lt 1 ];then
    #this is interactive mode
    #enable erasing input
    #stty erase '^?'
    printf "%-10s " "Name:" ;read NAME
    printf "%-10s " "Email:" ;read EMAIL
    printf "%-10s " "Address:" ;read ADDR
    printf "%-10s " "Phone:" ;read PHONE
else 
    #this is noninteractive mode
    USAGE="`basename $0` [-n name] [-e email] [-a address] [-p phone]";
   while getopts n:e:a:p:h OPT
    do
        case "$OPT" in
            n) NAME="$OPTARG";;
            e) EMAIL="$OPTARG";;
            a) ADDR="$OPTARG";;
            p) PHONE="$OPTARG";;
            h)
              echo "USAGE:$USAGE" ;
              exit 1;;
        esac
    done


fi

NAME="`remove_colon $NAME`"
EMAIL="`remove_colon $EMAIL`"
ADDR="`remove_colon $ADDR`"
PHONE="`remove_colon $PHONE`"

echo "$NAME:$EMAIL:$ADDR:$PHONE" >> "$MYADDRESSBOOK"
exit $?
